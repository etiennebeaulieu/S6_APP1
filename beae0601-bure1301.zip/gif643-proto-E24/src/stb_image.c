#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb/stb_image_write.h"
